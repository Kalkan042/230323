package com.acorn.springstartteacher;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringStartTeacherApplicationTests {

	@Test
	void contextLoads() {
	}

}
